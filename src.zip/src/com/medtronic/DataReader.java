/**
 * 
 */
package com.medtronic;

import java.nio.ByteBuffer;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import com.medtronic.WinsCard.Dword;
import com.medtronic.WinsCard.DwordByReference;
import com.medtronic.WinsCard.MCardLibrary;
import com.medtronic.WinsCard.SCardContextByReference;
import com.medtronic.WinsCard.SCardHandle;
import com.medtronic.WinsCard.SCardHandleByReference;
import com.medtronic.WinsCard.WinscardLibInfo;
import com.medtronic.exception.EstablishContextException;
import com.medtronic.exception.JnaPCSCException;

/**
 * @author oleksandr.volkovskyi
 *
 */
public class DataReader {

	private final WinsCard.WinscardLibInfo sCardlibInfo;
	private final WinsCard.MCardLibrary mCardLib;

	static final int MAX_ATR_SIZE = 33;

	public static final int SCARD_SCOPE_USER = 0;
	public static final int SCARD_SCOPE_TERMINAL = 1;
	public static final int SCARD_SCOPE_SYSTEM = 2;

	public static final int SCARD_S_SUCCESS = 0x0;
	public static final int SCARD_E_NO_READERS_AVAILABLE = 0x8010002E;
	public static final int SCARD_E_READER_UNAVAILABLE = 0x80100017;
	public static final int SCARD_E_NO_SMARTCARD = 0x8010000C;
	
	private SCardContextByReference phSCardContext;
	private SCardContextByReference phMCardContext;

	private SCardHandleByReference phMCardHandle;
	private byte[] mszReaders;

	public DataReader() {
		this(WinsCard.openSCardLib(), WinsCard.openLibMCard());
	}

	public DataReader(WinscardLibInfo openSCardLib, MCardLibrary openLibMCard) {
		this.sCardlibInfo = openSCardLib;
		this.mCardLib = openLibMCard;
	}

	public void init() {
		phSCardContext = new WinsCard.SCardContextByReference();
		try {
			check("SCardEstablishContext",
					sCardlibInfo.lib.SCardEstablishContext(new Dword(SCARD_SCOPE_SYSTEM), null, null, phSCardContext));
		} catch (JnaPCSCException e) {
			throw new EstablishContextException(e);
		}

		DwordByReference pcchReaders = new DwordByReference();
		byte[] mszReaders = null;
		long err;
		ByteBuffer mszReaderGroups = ByteBuffer.allocate("SCard$AllReaders".length() + 2);
		mszReaderGroups.put("SCard$AllReaders".getBytes(Charset.forName("ascii")));
		while (true) {
			err = sCardlibInfo.lib.SCardListReaders(phSCardContext.getValue(), mszReaderGroups, null, pcchReaders)
					.longValue();
			if (err != 0)
				break;
			mszReaders = new byte[pcchReaders.getValue().intValue()];
			err = sCardlibInfo.lib.SCardListReaders(phSCardContext.getValue(), mszReaderGroups,
					ByteBuffer.wrap(mszReaders), pcchReaders).longValue();
			if ((int) err != WinscardConstants.SCARD_E_INSUFFICIENT_BUFFER)
				break;
		}

		this.mszReaders = mszReaders;

	}
	
	
	
	public void initMCard(){
		DwordByReference dwDLLVersion = new DwordByReference();
		this.phMCardContext = new SCardContextByReference();
		if (mszReaders != null) {
			try {
				check("MCardInitialize", mCardLib.MCardInitialize(phSCardContext.getValue(),
						ByteBuffer.wrap(mszReaders), phMCardContext, dwDLLVersion));
			} catch (JnaPCSCException e) {
				e.printStackTrace();
			}
		}
	}
	
	public Dword  connectMcard(){
		
		this.phMCardHandle = new SCardHandleByReference();
		Dword result = mCardLib.MCardConnect(phMCardContext.getValue(), new Dword(1), (byte) 0x0C, phMCardHandle);
		return result;
	}

	public String[] readData() {

		byte[] buff = new byte[100];

		try {
			check("MCardReadMemory", mCardLib.MCardReadMemory(phMCardHandle.getValue(), (byte) 0, new Dword(0),
					ByteBuffer.wrap(buff), new DwordByReference(new Dword(buff.length + 10))));
		} catch (JnaPCSCException e) {
			e.printStackTrace();
		}

		String line = new String(buff);

		int index = 0;
		String[] arr = new String[5];
		int ctr = 0;
		int posistion = 0;
		while (index < line.length()) {
			int start = line.indexOf(31, posistion);
			int finish = line.indexOf(31, start + 1);
			if (finish != -1 && (finish - start) > 1) {
				if (line.charAt(finish - 1) != 32) {
					arr[ctr++] = line.substring(start+1, finish);
				}
				posistion = finish;
			} else {
				break;
			}

		}
		return arr;

	}

	public long isValidContext() {
		Dword result = null;

		if (phMCardContext != null) {
			result = sCardlibInfo.lib.SCardIsValidContext(phMCardContext.getValue());
		} else {
			result = new Dword(SCARD_E_NO_READERS_AVAILABLE);
		}
		return result.longValue();

	}

	public long getState() {
		DwordByReference readerLength = new DwordByReference();
		DwordByReference currentState = new DwordByReference();
		DwordByReference currentProtocol = new DwordByReference();
		ByteBuffer atrBuf = ByteBuffer.allocate(MAX_ATR_SIZE);
		DwordByReference atrLength = new DwordByReference(new Dword(MAX_ATR_SIZE));
		SCardHandle sCardHandle = new SCardHandle();
		Dword result = sCardlibInfo.lib.SCardStatus(sCardHandle, ByteBuffer.wrap(mszReaders), readerLength,
				currentState, currentProtocol, atrBuf, atrLength);

		System.out.println("Reader State Result :    " + result.longValue());
		try {
			check("SCardStatus", result.longValue());
		} catch (JnaPCSCException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return currentState.getValue().longValue();
	}

	private static void check(String message, Dword code) throws JnaPCSCException {
		check(message, code.longValue());
	}

	private static void check(String message, long code) throws JnaPCSCException {
		if (code == 0 || (int) code == 0)
			return;
		int icode = (int) code;
		String codeName = WinscardConstants.ERROR_TO_VARIABLE_NAME.get(icode);
		String codeDescription = WinscardConstants.ERROR_TO_DESCRIPTION.get(icode);
		throw new JnaPCSCException(code,
				String.format("%s got response 0x%x (%s: %s)", message, icode, codeName, codeDescription));
	}

	/** Simple wrapper around SCardListReaders. */
	public List<String> listReaderNames() {// throws JnaPCSCException {
		DwordByReference pcchReaders = new DwordByReference();
		byte[] mszReaders = null;
		long err;
		ByteBuffer mszReaderGroups = ByteBuffer.allocate("SCard$AllReaders".length() + 2);
		mszReaderGroups.put("SCard$AllReaders".getBytes(Charset.forName("ascii")));
		while (true) {
			err = sCardlibInfo.lib.SCardListReaders(phSCardContext.getValue(), mszReaderGroups, null, pcchReaders)
					.longValue();
			if (err != 0 && err != 6)
				break;
			mszReaders = new byte[pcchReaders.getValue().intValue()];
			err = sCardlibInfo.lib.SCardListReaders(phSCardContext.getValue(), mszReaderGroups,
					ByteBuffer.wrap(mszReaders), pcchReaders).longValue();
			if ((int) err != WinscardConstants.SCARD_E_INSUFFICIENT_BUFFER)
				break;
		}
		this.mszReaders = mszReaders;
		switch ((int) err) {
		case SCARD_S_SUCCESS:
			List<String> readerNames = pcsc_multi2jstring(mszReaders);
			return readerNames;
		case SCARD_E_NO_READERS_AVAILABLE:
		case SCARD_E_READER_UNAVAILABLE:
			return Collections.emptyList();
		default:
		return Collections.emptyList();
		}

	}

	private static List<String> pcsc_multi2jstring(byte[] multiString) {
		return pcsc_multi2jstring(multiString, Charset.forName("UTF-8"));
	}

	private static List<String> pcsc_multi2jstring(byte[] multiString, Charset charset) {
		List<String> r = new ArrayList<String>();
		int from = 0, to = 0;
		for (; to < multiString.length; to++) {
			if (multiString[to] != '\0')
				continue;
			if (from == to)
				return r;
			byte[] bytes = Arrays.copyOfRange(multiString, from, to);
			r.add(new String(bytes, charset));
			from = to + 1;
		}
		throw new IllegalArgumentException("Multistring must be end with a null-terminated empty string.");
	}
	
	public void disconnect(){
		long result = 0;
		//this.phMCardHandle = new SCardHandleByReference();
		try {
			result = mCardLib.MCardDisconnect( phMCardHandle.getValue());
			check("MCardDisconnect", result);
		} catch (JnaPCSCException e) {
			 e.printStackTrace();
		}
		
		try {
			result = mCardLib.MCardShutdown(phMCardContext.getValue());
			check("MCardShutdown", result);
		} catch (JnaPCSCException e) {
			 e.printStackTrace();
		}
	}
}
