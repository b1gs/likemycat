/**
 * 
 */
package com.medtronic;

/**
 * @author oleksandr.volkovskyi
 *
 */
public interface CardReaderListener {
	
	void update(); 
	
}
