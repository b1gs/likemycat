package com.medtronic.exception;

import javax.smartcardio.CardException;

public class JnaCardException extends CardException {
	private static final long serialVersionUID = 1L;
	public final int sw;
	public JnaCardException(int sw, String message) {this(sw, message, null);}
	public JnaCardException(int sw, String message, Throwable cause) {super(message, cause); this.sw = sw;}
}
