/**
 * 
 */
package com.medtronic;

import java.io.BufferedReader;
import java.io.Closeable;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.Socket;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.xml.bind.DatatypeConverter;

/**
 * @author oleksandr.volkovskyi
 *
 */
public class SocketThread extends Thread implements CardReaderListener {

	private static final Logger LOGGER = Logger.getLogger(SocketThread.class.getName());
	private boolean handshaked = false;
	protected Socket socket;
	private volatile boolean needToNotify = false;
	private volatile boolean stop = false;
	private final DaemonThread daemon;

	public SocketThread(Socket clientSocket, DaemonThread daemon) {
		this.socket = clientSocket;
		this.daemon = daemon;
	}

	@SuppressWarnings("resource")
	public void run() {
		InputStream inp = null;
		BufferedReader brinp = null;
		DataOutputStream out = null;
		try {
			inp = socket.getInputStream();
			brinp = new BufferedReader(new InputStreamReader(inp));
			out = new DataOutputStream(socket.getOutputStream());

			if (!handshaked) {

				String data = new Scanner(inp, "UTF-8").useDelimiter("\\r\\n\\r\\n").next();

				Matcher get = Pattern.compile("^GET").matcher(data);

				if (get.find()) {
					Matcher match = Pattern.compile("Sec-WebSocket-Key: (.*)").matcher(data);
					match.find();
					byte[] response = ("HTTP/1.1 101 Switching Protocols\r\n" + "Connection: Upgrade\r\n"
							+ "Upgrade: websocket\r\n" + "Sec-WebSocket-Accept: "
							+ DatatypeConverter.printBase64Binary(MessageDigest.getInstance("SHA-1").digest(
									(match.group(1) + "258EAFA5-E914-47DA-95CA-C5AB0DC85B11").getBytes("UTF-8")))
							+ "\r\n\r\n").getBytes("UTF-8");

					socket.getOutputStream().write(response, 0, response.length);

				}
				handshaked = true;
			}

			while (!stop) {
				if (needToNotify) {
					byte []  message = constructMessage();
					out.write(message);
					LOGGER.log(Level.INFO, "Sending message to client. ");
					needToNotify = false;
				}
				sleep(500);
			}
		} catch (IOException | NoSuchAlgorithmException | InterruptedException e) {
			e.printStackTrace();
		} finally {
			tryCloseResource(inp);
			tryCloseResource(brinp);
			tryCloseResource(out);
		}
		LOGGER.log(Level.INFO, "Stopping SocketThread.... ");
	}

	@Override
	public void update() {
		needToNotify = true;
	}

	private byte[] constructMessage() {
		byte[] formattedDytes = new byte[20];
		formattedDytes[0] = (byte) 129;
		
		String data = daemon.getData();
		int length = data.length();
		int rawDataIndex = -1;
		if (length <= 125) {
			formattedDytes[1] = (byte) length;
			rawDataIndex = 2;
		} else if (126 <= length && length <= 65535) {
			formattedDytes[1] = (byte) 126;
			formattedDytes[2] = (byte) ((length >> 8) & 255);
			formattedDytes[3] = (byte) (length & 255);
			rawDataIndex = 4;
		}
		byte[] response = new byte[rawDataIndex + length];
		System.arraycopy(formattedDytes, 0, response, 0, rawDataIndex);
		System.arraycopy(data.getBytes(), 0, response, rawDataIndex, length);

		return response;
	}

	private void tryCloseResource(Closeable res) {
		if (res != null) {
			try {
				LOGGER.log(Level.INFO, "Trying to close resource.. {0}", res.getClass());
				res.close();
				LOGGER.log(Level.INFO, "Resource {0} closed.", res.getClass());
			} catch (IOException e) {
				LOGGER.log(Level.SEVERE, e.toString(), e);
			}

		}
	}
	
	public void stopThread(){
		LOGGER.log(Level.INFO, "Received stop command on SocketThread");
		try {
			socket.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
		stop = true;
		System.exit(0);
	}
}
