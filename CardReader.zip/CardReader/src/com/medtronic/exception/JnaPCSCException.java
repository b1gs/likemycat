package com.medtronic.exception;

import javax.smartcardio.CardException;

public class JnaPCSCException extends CardException{
	private static final long serialVersionUID = 1L;
	public final long code;
	public JnaPCSCException(String message) {this(0, message, null);}
	public JnaPCSCException(Throwable cause) {this(0, null, cause);}
	public JnaPCSCException(long code, String message) {this(code, message, null);}
	public JnaPCSCException(long code, String message, Throwable cause) {super(message, cause); this.code = code;}
}
