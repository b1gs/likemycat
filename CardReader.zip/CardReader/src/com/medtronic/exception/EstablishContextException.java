package com.medtronic.exception;

public class EstablishContextException extends RuntimeException {
	private static final long serialVersionUID = 1L;
	public EstablishContextException(JnaPCSCException cause) {super(cause);}
	/** Overridden with more specific return type so you don't have to cast,*/
	@Override public JnaPCSCException getCause() {return (JnaPCSCException) super.getCause();}
}
