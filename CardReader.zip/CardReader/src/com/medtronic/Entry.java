package com.medtronic;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.LinkedList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;


/**
 * @author oleksandr.volkovskyi
 *
 */
public class Entry {

	private static final Logger LOGGER = Logger.getLogger(Entry.class.getName());
	
	private static DaemonThread daemon;
	private static List<SocketThread> list = new LinkedList<SocketThread>();
	private static boolean stop = false;
	private static ServerSocket serverSocket;
	private static Socket socket = null;
	
	public static void main(String[] args) {

		LOGGER.info("Main Method Entry");
		daemon = new DaemonThread();
		daemon.start();
		
		
	        try {
	            serverSocket = new ServerSocket(4000);
	        } catch (IOException e) {
	            e.printStackTrace();

	        }
	        while (!stop) {
	            try {
	                socket = serverSocket.accept();
	            } catch (IOException e) {
	            	LOGGER.log(Level.SEVERE, e.toString(), e);
	            }
	            SocketThread socThread = new SocketThread(socket,daemon);
	            socThread.start();
	            list.add(socThread);
	            daemon.addCardReaderListener(socThread);
	            daemon.notifyListeners();
	        }
	        LOGGER.log(Level.INFO, "Entry daemon exits...");    

	}
	
	public static void stop(){
		LOGGER.log(Level.INFO, "Stop Command received.. ");
		stop = true;
		daemon.stopThread();
		try {
			serverSocket.close();
		} catch (IOException e) {
		}
	}
}
