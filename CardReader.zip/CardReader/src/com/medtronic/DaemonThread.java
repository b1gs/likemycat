/**
 * 
 */
package com.medtronic;

import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;

import com.medtronic.WinsCard.Dword;

/**
 * @author oleksandr.volkovskyi
 *
 */
public class DaemonThread extends Thread {

	private static final Logger LOGGER = Logger.getLogger(DaemonThread.class.getName());

	private static long currentState = 3;
	private static DataReader reader = new DataReader();

	private static int prevReadersSize = 0;
	private boolean stop = false;

	private final Set<CardReaderListener> listeners;

	public DaemonThread() {
		super();
		listeners = new HashSet<CardReaderListener>();
	}

	public void run() {
		LOGGER.log(Level.INFO, "Card reader daemon started");
		reader.init();
		try {
			while (!stop) {
				try {
					List<String> readers = reader.listReaderNames();
					if (readers.size() == 0) {
						notifyIfRequired(WinscardConstants.SCARD_E_READER_UNAVAILABLE);
					}

					if (readers.size() == 1 && prevReadersSize == 0) {
						prevReadersSize = readers.size();
						reader.initMCard();
					} else if (readers.size() == 0 && prevReadersSize == 1) {
						prevReadersSize = readers.size();
						reader.disconnect();
					}

					if (readers.size() == 1) {
						Dword result = reader.connectMcard();
						notifyIfRequired(result.longValue());
					}

					sleep(500);
				} catch (Exception x) {
					x.printStackTrace();
				}

			}
		} catch (Exception x) {
			x.printStackTrace();
		} finally {
			LOGGER.log(Level.INFO, "Card reader daemon thread exit");
		}
	}

	public void addCardReaderListener(CardReaderListener listener) {
		listeners.add(listener);
	}

	public void removeCardReaderListener(CardReaderListener listener) {
		listeners.remove(listener);
	}

	public void notifyListeners(String data) {
		for (CardReaderListener listener : listeners) {
			listener.update(data);
		}
	}

	public void stopThread(){
		stop = true;
		
	}
	
	private void notifyIfRequired(long state) {
		if (currentState != state && state != 0) {
			notifyListeners(buildData(state));
			LOGGER.log(Level.INFO, "Current state:  {0} ", buildData(state));
		} else if (currentState != state && state == 0) {
			String data = buildData(state);
			if (data != null) {
				notifyListeners(buildData(state));
				LOGGER.log(Level.INFO, "Current state:  {0} ", buildData(state));
			}
		}
		currentState = state;
	};

	public void notifyCurrentState() {
		notifyListeners(buildData(currentState));
	}

	private String buildData(long state) {
		String message;
		if (state != 0) {
			message = "{ 'state' :'" + (int) state + "', 'data' : '"
					+ WinscardConstants.ERROR_TO_DESCRIPTION.get((int) state) + "' }";
		} else {
			String[] data = reader.readData();
			if (data[1] != null && data[2] != null && data[4] != null) {
				message = "{ 'state' : '" + state + "', 'data' : '{ 'firstName' : ' " + data[0] + "' , 'lastName' : '"
						+ data[1] + "' , 'username' :'" + data[2] + "', 'id' : '" + data[4] + "' }}";
			} else {
				message = null;
			}
		}
		return message;
	}

}
