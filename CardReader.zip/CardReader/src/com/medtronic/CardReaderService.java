/**
 * 
 */
package com.medtronic;


/**
 * @author oleksandr.volkovskyi
 *
 */
public class CardReaderService {

	public static void start(String[] args) {
        System.out.println("start");
        Entry.main(args);
    }
 
    public static void stop(String[] args) {
        System.out.println("stop");
        Entry.stop();
    }
 
    public static void main(String[] args) {
        if ("start".equals(args[0])) {
            start(args);
        } else if ("stop".equals(args[0])) {
            stop(args);
        }
    }

}
